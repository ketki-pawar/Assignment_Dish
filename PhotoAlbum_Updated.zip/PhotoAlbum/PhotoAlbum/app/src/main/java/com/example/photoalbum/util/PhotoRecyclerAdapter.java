package com.example.photoalbum.util;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.photoalbum.R;
import com.example.photoalbum.model.Photo;


import java.util.List;
//Adapter for recyclerview displaying Photos on Second page
public class PhotoRecyclerAdapter extends RecyclerView.Adapter<PhotoRecyclerAdapter.CustomViewHolder> {
    private Context context;
    private List<Photo> photoList;
    private ItemClickListener itemClickListener;

    public PhotoRecyclerAdapter(Context context, List<Photo> photoList, ItemClickListener itemClickListener) {
        this.context = context;
        this.photoList = photoList;
        this.itemClickListener = itemClickListener;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recyclerview_item_photo, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PhotoRecyclerAdapter.CustomViewHolder holder, int position) {


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClickListener.onThumbnailClick(photoList.get(position));
                RequestOptions myOptions = new RequestOptions()
                        .centerCrop();

                Glide.with(context)
                        .asBitmap()
                        .apply(myOptions)
                        .load(photoList.get(position).getUrl())
                        .into(holder.imageView);
            }
        });

        //Dummy code for testing

       /* RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher_round)
                .error(R.mipmap.ic_launcher_round);*/


//String imgUrl ="https://source.unsplash.com/random";
        //imgUrl = imgUrl.replace("https", "http");
        // new DownloadImageTask(holder.imageView).execute("http://i.imgur.com/DvpvklR.png");

  /*   Picasso.with(context)
                .load("https://source.unsplash.com/random")
                .into(holder.imageView);*/
        //Picasso.with(context).load(imgUrl).resize(150,150).into(holder.imageView);
        //Glide.with(context).load(this.photoList.get(position).getThumbnailUrl()).into(holder.imageView);


        String imgUrl = "https://random.imagecdn.app/150/150";
        //below thumbNailurl doesn not work
        // String imgUrl =photoList.get(position).getThumbnailUrl();
        Log.e("TAG", "thumbnail url" + imgUrl);
        Glide.with(context).load(imgUrl).into(holder.imageView);


    }

    public void setPhotoList(List<Photo> photoList) {
        this.photoList = photoList;
        this.notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (this.photoList != null) {
            return this.photoList.size();
        }
        return 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        public CustomViewHolder(View itemView) {
            super(itemView);
            imageView = (ImageView) itemView.findViewById(R.id.image);

        }
    }

}
