package com.example.photoalbum.util;

import com.example.photoalbum.model.Album;
import com.example.photoalbum.model.Photo;
//Interface to handle onItem clicks
public interface ItemClickListener {
    public void onItemClick(Album album);

    public void onThumbnailClick(Photo photo);
}
