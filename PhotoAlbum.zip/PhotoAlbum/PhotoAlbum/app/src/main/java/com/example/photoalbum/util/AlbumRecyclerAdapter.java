package com.example.photoalbum.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.photoalbum.R;
import com.example.photoalbum.model.Album;

import java.util.List;

public class AlbumRecyclerAdapter extends RecyclerView.Adapter<AlbumRecyclerAdapter.CustomViewHolder>{
    private Context context;
    private List<Album> albumList;
    private ItemClickListener itemClickListener;

    public AlbumRecyclerAdapter(Context context, List<Album> albumList, ItemClickListener itemClickListener) {
        this.context = context;
        this.albumList = albumList;
        this.itemClickListener = itemClickListener;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.recyclerview_row_item_album,parent,false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AlbumRecyclerAdapter.CustomViewHolder holder, int position) {
        holder.titleTv.setText(this.albumList.get(position).getTitle().toString());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClickListener.onItemClick(albumList.get(position));
            }
        });

    }
    public void setAlbumList(List<Album> albumList) {
        this.albumList = albumList;
        this.notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(this.albumList != null) {
            return this.albumList.size();
        }
        return 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder{
        TextView titleTv;
        public CustomViewHolder(View itemView) {
            super(itemView);
           titleTv=(TextView) itemView.findViewById(R.id.titleText);
        }
    }

}
