package com.example.photoalbum.viewmodel;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.photoalbum.model.Album;
import com.example.photoalbum.model.Photo;
import com.example.photoalbum.network.APIInterface;
import com.example.photoalbum.network.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AlbumViewModel extends ViewModel {
    private MutableLiveData<List<Album>> albumList;

    public AlbumViewModel(){
        albumList = new MutableLiveData<>();
    }

    public MutableLiveData<List<Album>> getAlbumListObserver() {
        return albumList;

    }

    public void makeApiCallForFectchingAlbum() {
        APIInterface apiInterface = RetrofitClient.getRetrofitClient().create(APIInterface.class);
        Call<List<Album>> call = apiInterface.getAlbumList();
        call.enqueue(new Callback<List<Album>>() {
            @Override
            public void onResponse(Call<List<Album>> call, Response<List<Album>> response) {
                albumList.postValue(response.body());
                Log.e("TAG", "albumList response="+response.body() );
            }

            @Override
            public void onFailure(Call<List<Album>> call, Throwable t) {
                albumList.postValue(null);
                Log.e("TAG", "albumList onFailure="+t.getLocalizedMessage() );
            }


        });
    }

}
