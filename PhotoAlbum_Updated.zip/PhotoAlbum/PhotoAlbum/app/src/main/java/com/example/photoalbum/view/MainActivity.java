package com.example.photoalbum.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.photoalbum.R;
import com.example.photoalbum.model.Album;
import com.example.photoalbum.model.Photo;
import com.example.photoalbum.util.AlbumRecyclerAdapter;
import com.example.photoalbum.util.ItemClickListener;
import com.example.photoalbum.util.PhotoRecyclerAdapter;
import com.example.photoalbum.viewmodel.AlbumViewModel;
import com.example.photoalbum.viewmodel.PhotoViewModel;

import java.util.List;

//Main Activity displaying Albums in a list
public class MainActivity extends AppCompatActivity implements ItemClickListener {
    RecyclerView recyclerView;
    AlbumRecyclerAdapter adapter;

    private List<Album> albumList;
    private List<Photo> photoList;
    private ItemClickListener itemClickListener;
    private AlbumViewModel albumViewModel;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.recyclerView);
       recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        adapter =  new AlbumRecyclerAdapter(this, albumList, this);

        recyclerView.setAdapter(adapter);



        albumViewModel= ViewModelProviders.of(this).get(AlbumViewModel.class);

        albumViewModel.getAlbumListObserver().observe(this, new Observer<List<Album>>() {
            @Override
            public void onChanged(List<Album> albumModelList) {
                if(albumModelList != null) {
                    albumList = albumModelList;
                    adapter.setAlbumList(albumList);
                }
            }
        });

        albumViewModel.makeApiCallForFectchingAlbum();
    }


    @Override
    public void onItemClick(Album album) {
        Toast.makeText(this, "Clicked Album Name is : " +album.getTitle(), Toast.LENGTH_SHORT).show();
        Intent intentDisplayPhotoActivity=new Intent(getApplicationContext(),PhotoDisplayActivity.class);
       intentDisplayPhotoActivity.putExtra("id",album.getId());
        startActivity(intentDisplayPhotoActivity);

    }

    @Override
    public void onThumbnailClick(Photo photo) {
        Toast.makeText(this, "Clicked Photo is : " +photo.getTitle(), Toast.LENGTH_SHORT).show();

    }
}