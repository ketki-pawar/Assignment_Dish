package com.example.photoalbum.viewmodel;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.photoalbum.model.Album;
import com.example.photoalbum.model.Photo;
import com.example.photoalbum.network.APIInterface;
import com.example.photoalbum.network.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PhotoViewModel extends ViewModel {
    private MutableLiveData<List<Photo>> photoList;

    public PhotoViewModel(){
        photoList = new MutableLiveData<>();
    }

    public MutableLiveData<List<Photo>> getPhotoListObserver() {
        return photoList;

    }


    public void makeApiCallForFectchingPhotos() {
        APIInterface apiInterface = RetrofitClient.getRetrofitClient().create(APIInterface.class);
        Call<List<Photo>> call = apiInterface.getPhotoList();
        call.enqueue(new Callback<List<Photo>>() {
            @Override
            public void onResponse(Call<List<Photo>> call, Response<List<Photo>> response) {
                photoList.postValue(response.body());
                Log.e("TAG", "albumList response="+response.body() );
            }

            @Override
            public void onFailure(Call<List<Photo>> call, Throwable t) {
                photoList.postValue(null);
                Log.e("TAG", "albumList onFailure="+t.getLocalizedMessage() );
            }


        });
    }
}
