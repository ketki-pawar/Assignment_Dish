package com.example.photoalbum.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.photoalbum.R;

public class PhotoDisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_display);


    }
}