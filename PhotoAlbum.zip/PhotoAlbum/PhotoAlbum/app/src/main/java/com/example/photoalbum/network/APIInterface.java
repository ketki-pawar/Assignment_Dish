package com.example.photoalbum.network;

import com.example.photoalbum.model.Album;
import com.example.photoalbum.model.Photo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface APIInterface {

    @GET("albums")
    Call<List<Album>> getAlbumList();

    @GET("albums/{id}/photos")
    Call<List<Photo>> getPhotoList();
}
