package com.example.photoalbum.model;

public class Repository {
}
