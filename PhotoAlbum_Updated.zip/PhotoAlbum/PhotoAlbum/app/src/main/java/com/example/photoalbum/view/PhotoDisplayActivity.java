package com.example.photoalbum.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.photoalbum.R;
import com.example.photoalbum.model.Album;
import com.example.photoalbum.model.Photo;
import com.example.photoalbum.util.AlbumRecyclerAdapter;
import com.example.photoalbum.util.ItemClickListener;
import com.example.photoalbum.util.PhotoRecyclerAdapter;
import com.example.photoalbum.viewmodel.PhotoViewModel;

import java.util.List;

//Detail page displaying photos in that album
public class PhotoDisplayActivity extends AppCompatActivity implements ItemClickListener {
    private RecyclerView recyclerViewPhoto;
    private PhotoRecyclerAdapter photoRecyclerAdapter;
    private List<Photo> photoList;
    private PhotoViewModel photoViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_display);


        recyclerViewPhoto=findViewById(R.id.recyclerViewPhoto);
         LinearLayoutManager layoutManager = new GridLayoutManager(this, 3);
        recyclerViewPhoto.setLayoutManager(layoutManager);

        photoRecyclerAdapter =  new PhotoRecyclerAdapter(this, photoList, this);
        // adapter=new AlbumRecyclerAdapter(this,albumList, itemClickListener);
        recyclerViewPhoto.setAdapter(photoRecyclerAdapter);
        photoViewModel= ViewModelProviders.of(this).get(PhotoViewModel.class);

        photoViewModel.getPhotoListObserver().observe(this, new Observer<List<Photo>>() {
            @Override
            public void onChanged(List<Photo> photoModelList) {
                if(photoModelList != null) {
                    photoList = photoModelList;
                    photoRecyclerAdapter.setPhotoList(photoList);
                }
            }
        });
        Bundle extras = getIntent().getExtras();
        int id=0;
        if (extras != null) {
             id = extras.getInt("id");

        }

        photoViewModel.makeApiCallForFectchingPhotos(id);

    }

    @Override
    public void onItemClick(Album album) {

    }

    @Override
    public void onThumbnailClick(Photo photo) {
        Toast.makeText(this, "Clicked Photo is : " +photo.getTitle(), Toast.LENGTH_SHORT).show();

    }
}