package com.example.photoalbum.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.photoalbum.R;
import com.example.photoalbum.model.Album;
import com.example.photoalbum.util.AlbumRecyclerAdapter;
import com.example.photoalbum.util.ItemClickListener;
import com.example.photoalbum.viewmodel.AlbumViewModel;
import com.example.photoalbum.viewmodel.PhotoViewModel;

import java.util.List;


public class MainActivity extends AppCompatActivity implements ItemClickListener {
    RecyclerView recyclerView;
    AlbumRecyclerAdapter adapter;
    private List<Album> albumList;
    private ItemClickListener itemClickListener;
    private AlbumViewModel albumViewModel;
    private PhotoViewModel photoViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.recyclerView);
       recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));


      //  LinearLayoutManager layoutManager = new GridLayoutManager(this, 2);
      //  recyclerView.setLayoutManager(layoutManager);
        adapter =  new AlbumRecyclerAdapter(this, albumList, this);
       // adapter=new AlbumRecyclerAdapter(this,albumList, itemClickListener);
        recyclerView.setAdapter(adapter);

        albumViewModel= ViewModelProviders.of(this).get(AlbumViewModel.class);
        photoViewModel= ViewModelProviders.of(this).get(PhotoViewModel.class);
        albumViewModel.getAlbumListObserver().observe(this, new Observer<List<Album>>() {
            @Override
            public void onChanged(List<Album> albumModelList) {
                if(albumModelList != null) {
                    albumList = albumModelList;
                    adapter.setAlbumList(albumList);
                }
            }
        });

        albumViewModel.makeApiCallForFectchingAlbum();
    }


    @Override
    public void onItemClick(Album album) {
        Toast.makeText(this, "Clicked Album Name is : " +album.getTitle(), Toast.LENGTH_SHORT).show();
        photoViewModel.makeApiCallForFectchingPhotos();
    }
}