package com.example.photoalbum.util;

import com.example.photoalbum.model.Album;

public interface ItemClickListener {
    public void onItemClick(Album album);
}
